package com.ZZH.model;

import java.util.Scanner;

public class HighSpeedRail {
	private double[] price={0,44.5,64.5,99.5,129.5,159.5,219.5,0,29.5,39.5,64.5,79.5,99.5,139.5};
	private String[] platfoms={"南京","镇江","丹阳","常州","无锡","苏州","上海",""};
	public HighSpeedRail(){
		
	}
	public int query(String platfom){
		int i=0;
		for(;i<platfoms.length-1;i++){
			if(platfom.equals(platfoms[i])){
				break;
			}
		}
		return i;	
	}
	public void result1(int i){
		System.out.println("你需支付的价格为：" +price[i]);
	}
	public static void main(String[] args) {
		int i=7;
		HighSpeedRail HSR=new HighSpeedRail();
		System.out.println("请输入你想要到达的站台");
		for (;i==7;){
			Scanner a= new Scanner(System.in);
			String  platfom= a.nextLine();
			i=HSR.query(platfom);
		}
		/*直到输入正确的站台名 才能进行下一步。 i默认是7只有i不为7的时候跳出循环
		上面的result方法输入正确的值可以返回0到6均可退出循环，输入错误的值则会
		返回7 继续循环让你输入站台名
		*/
		System.out.println("请输入你想要的座位对应的数字：1.一等座，2.二等座");
		int  seat=0;
		for(;seat<1||seat>2;){
			Scanner b = new Scanner(System.in);
			String sit= b.nextLine();
			seat=Integer.parseInt(sit);						
			}
		//直到输入正确的座位数字才能进行下一步 
			if(seat==1){
				HSR.result1(i);
			}else{
				i=i+7;
				HSR.result1(i);
			}
		
		
	}
}