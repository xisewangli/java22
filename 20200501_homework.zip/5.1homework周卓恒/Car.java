package com.ZZH.model;

public class Car {
	private String brand;//品牌
	private String vehicleType;//车型
	private double price;
	private double consumption;//油耗
	private double kilometer;//里程数
	private double tank;//邮箱容积
	private double remainOil;
	public Car(String brand,String vehicleType,double price,double consumption,double kilometer,double tank,double remainOil){
		this.brand=brand;
		this.vehicleType=vehicleType;
		this.price=price;
		this.consumption=consumption;
		this.kilometer=kilometer;
		this.tank=tank;
		this.remainOil=remainOil;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getConsumption() {
		return consumption;
	}
	public void setConsumption(double consumption) {
		this.consumption = consumption;
	}
	public double getKilometer() {
		return kilometer;
	}
	public void setKilometer(double kilometer) {
		this.kilometer = kilometer;
	}
	public double getTank() {
		return tank;
	}
	public void setTank(double tank) {
		this.tank = tank;
	}
	public double getRemainOil() {
		return remainOil;
	}
	public void setRemainOil(double remainOil) {
		this.remainOil = remainOil;
	}
	@Override
	public String toString() {
		return "品牌=" + brand + ", 车型=" + vehicleType + ", 价格=" + price + ", 油耗="
				+ consumption + ", 里程数=" + kilometer + ", 油箱容积=" + tank + ", 剩余油量=" + remainOil;
	}
	public double kilomRe(Car car){
		  double kilomRe =( kilometer /100)*consumption;
	      remainOil=(int) (remainOil- kilomRe);
		return kilomRe;
		
	}
	
}
